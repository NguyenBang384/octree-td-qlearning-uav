"""
paper2_sim.py

Bai bao 2 (JST, ma 1279): Lam min cay bat phan tuong doi theo sai phan thoi gian cho hoc Q dang bang
trong lap tuyen UAV 3D. Ban da sua theo phan bien.

Noi dung: dong hoc ba chieu nam trang thai, bo loc co dong du phong dung chung cho moi cach bieu
dien, luoi deu, cay bat phan voi luat tinh chia tuong doi (14) va ba dai luong thay the (16),
huan luyen, danh gia va ve hinh hai ngon ngu. Phan 7 bo sung cac thi nghiem vong phan bien:
nhieu hat giong, ba ban do (S, M, D), luat dem lan ghe, nguong tuyet doi, nhan phan thuong,
Double DQN co mat na, tim kiem A*, kiem chung Menh de 1 tren bang dong bang, Hinh 8-10.

Chay:
  python3 paper2_sim.py --quick          chay rut gon (hai cau hinh, 1500 tap) va ve hinh
  python3 paper2_sim.py --all            chay day du 17 cau hinh x 6000 tap (khoang 3 - 4 gio)
  python3 paper2_sim.py --jobs u12 a_td  chay cac cau hinh chon loc
  python3 paper2_sim.py --figs           chi ve lai Hinh 2-7 tu cac tep JSON da co
  python3 paper2_sim.py --rev M_td_s2027 S_td_s2026 astar   thi nghiem phan bien chon loc
  python3 paper2_sim.py --revall         toan bo thi nghiem phan bien (khoang 6 gio, mot nhan)
  python3 paper2_sim.py --revfigs        ve Hinh 8, 9, 10 tu ../figs/p2r

Tac gia: Nguyen Van Bang, Khoa Ten lua, Hoc vien Phong khong-Khong quan, Ha Noi, Viet Nam.
"""
import os
import sys
import json
import glob
import math
import time
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt



# ============ 1. MO HINH, HINH HOC VA BO LOC DU PHONG ============
CFG = dict(
    Lx=100.0, Ly=100.0, Zmin=2.0, Zmax=42.0,
    v=2.0, dt=1.0, wmax=math.radians(25.0), gdot=math.radians(8.0),
    gmax=math.radians(16.0), safeR=1.5,
    start=(6.0, 6.0, 8.0), goal=(94.0, 94.0, 30.0),
    psi0=math.radians(45.0), gam0=0.0, goal_rad=4.0,
    R_goal=250.0, R_hit=-250.0, R_timeout=-80.0,
    beta=1.0, lam=0.06, turn_pen=0.05, clb_pen=0.04,
    gamma=1.0, alpha0=0.25, alpha_min=3e-3, alpha_decay=0.99985,
    eps0=1.0, eps_min=0.05, eps_decay=0.99940, Tmax=260,
)

AYAW = np.array([-CFG["wmax"], 0.0, +CFG["wmax"]])
AGAM = np.array([-CFG["gdot"], 0.0, +CFG["gdot"]])
NACT = 9
UY = np.repeat(AYAW, 3)          # a // 3
UG = np.tile(AGAM, 3)            # a %  3

THREATS = [
    (30.0, 34.0, 14.0, 11.0, 1), (58.0, 30.0, 12.0, 9.0, 1),
    (36.0, 66.0, 16.0, 10.0, 1), (70.0, 62.0, 14.0, 9.0, 1),
    (18.0, 62.0, 10.0, 7.0, 1), (82.0, 40.0, 12.0, 8.0, 1),
    (50.0, 50.0, 22.0, 9.0, 0), (24.0, 86.0, 18.0, 8.0, 0),
    (86.0, 78.0, 20.0, 8.0, 0), (62.0, 86.0, 16.0, 7.0, 0),
    (44.0, 16.0, 20.0, 7.0, 0), (76.0, 16.0, 18.0, 7.0, 0),
]
_T = np.array(THREATS, dtype=np.float64)
TCX, TCY, TCZ, TR, TK = _T[:, 0], _T[:, 1], _T[:, 2], _T[:, 3], _T[:, 4]
_SPH = TK == 0


def wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def clear_v(P):
    """Khoang ho ky hieu toi bien gan nhat. P co dang (..., 3), tra ve (...)."""
    Q = P.reshape(-1, 3)
    dx = Q[:, 0:1] - TCX; dy = Q[:, 1:2] - TCY; dz = Q[:, 2:3] - TCZ
    rxy = np.sqrt(dx * dx + dy * dy)
    dsph = np.sqrt(rxy * rxy + dz * dz) - TR
    dr = rxy - TR
    dzz = np.abs(dz) - TCZ                       # tru dung tu mat dat toi 2*cz
    dcyl = np.where(dzz <= 0.0, dr, np.hypot(np.maximum(dr, 0.0), dzz))
    d = np.where(_SPH, dsph, dcyl)
    return d.min(axis=1).reshape(P.shape[:-1])


def clearance(x, y, z):
    return float(clear_v(np.array([[x, y, z]], dtype=np.float64))[0])


def succ_all(S):
    """S: (N, 5) -> (N, 9, 5) trang thai ke tiep cua chin hanh dong."""
    S = np.atleast_2d(S)
    ps = wrap(S[:, 3:4] + UY[None, :] * CFG["dt"])
    gm = np.clip(S[:, 4:5] + UG[None, :] * CFG["dt"], -CFG["gmax"], CFG["gmax"])
    cg = np.cos(gm)
    x = S[:, 0:1] + CFG["v"] * cg * np.cos(ps) * CFG["dt"]
    y = S[:, 1:2] + CFG["v"] * cg * np.sin(ps) * CFG["dt"]
    z = S[:, 2:3] + CFG["v"] * np.sin(gm) * CFG["dt"]
    return np.stack([x, y, z, ps, gm], axis=-1)


def nxt(s, a):
    return tuple(succ_all(np.asarray(s, dtype=np.float64)[None, :])[0, a])


_TAU = np.array([0.25, 0.5, 0.75, 1.0])


_TAU2 = np.array([0.5, 1.0])


def seg_ok_v(P0, P1, safeR, tau=None):
    """P0, P1: (..., 3). Kiem cac diem mau tren doan noi va bien khong gian lam viec."""
    if tau is None:
        tau = _TAU
    d = P1 - P0
    P = P0[..., None, :] + d[..., None, :] * tau[:, None]
    inb = ((P[..., 0] >= 0.0) & (P[..., 0] <= CFG["Lx"])
           & (P[..., 1] >= 0.0) & (P[..., 1] <= CFG["Ly"])
           & (P[..., 2] >= CFG["Zmin"]) & (P[..., 2] <= CFG["Zmax"]))
    ok = inb & (clear_v(P) > safeR)
    return ok.all(axis=-1)


def onestep(S, safeR=None):
    """(N, 9) mat na mot buoc, kem trang thai ke tiep."""
    if safeR is None:
        safeR = CFG["safeR"]
    SN = succ_all(S)
    return seg_ok_v(np.atleast_2d(S)[:, None, :3], SN[..., :3], safeR), SN


def viable2(s, safeR=None):
    """Mat na kha ton hai buoc cho mot trang thai. Tra ve (danh sach hanh dong, SN)."""
    S = np.asarray(s, dtype=np.float64)[None, :]
    m1, SN = onestep(S, safeR)
    m1 = m1[0]
    idx = np.nonzero(m1)[0]
    if idx.size == 0:
        return [4], SN[0]
    m2, _ = onestep(SN[0, idx], safeR)
    keep = idx[m2.any(axis=1)]
    if keep.size == 0:
        return idx.tolist(), SN[0]
    return keep.tolist(), SN[0]


def onestep_list(s, safeR=None):
    S = np.asarray(s, dtype=np.float64)[None, :]
    m1, SN = onestep(S, safeR)
    idx = np.nonzero(m1[0])[0]
    return (idx.tolist() if idx.size else [4]), SN[0]


def _step_ctrl(S, uy, ug):
    """Mot buoc voi lenh quay uy va lenh goc quy dao ug, dang mang."""
    ps = wrap(S[..., 3] + uy * CFG["dt"])
    gm = np.clip(S[..., 4] + ug * CFG["dt"], -CFG["gmax"], CFG["gmax"])
    cg = np.cos(gm)
    x = S[..., 0] + CFG["v"] * cg * np.cos(ps) * CFG["dt"]
    y = S[..., 1] + CFG["v"] * cg * np.sin(ps) * CFG["dt"]
    z = S[..., 2] + CFG["v"] * np.sin(gm) * CFG["dt"]
    return np.stack([x, y, z, ps, gm], axis=-1)


_HIDX = {}


def backup_traj(S, H=10):
    """Quy dao du phong dang dong kin: quay deu cuc dai va san bang goc quy dao.

    S: (N, 5). Tra ve (N, 2, H+1, 3).
    """
    dt = CFG["dt"]; v = CFG["v"]; gd = CFG["gdot"]
    h = _HIDX.get(H)
    if h is None:
        h = _HIDX[H] = np.arange(1, H + 1, dtype=np.float64)
    sgn = np.array([+1.0, -1.0])[None, :, None]
    ps0 = S[:, None, None, 3]; gm0 = S[:, None, None, 4]
    ps = ps0 + sgn * CFG["wmax"] * dt * h[None, None, :]        # (N, 2, H)
    gm = np.sign(gm0) * np.maximum(np.abs(gm0) - gd * dt * h[None, None, :], 0.0)
    cg = np.cos(gm) * (v * dt)
    dx = np.cumsum(cg * np.cos(ps), axis=2)
    dy = np.cumsum(cg * np.sin(ps), axis=2)
    dz = np.cumsum(np.sin(gm) * (v * dt), axis=2)
    out = np.empty((S.shape[0], 2, H + 1, 3))
    out[:, :, 0, 0] = S[:, None, 0]; out[:, :, 0, 1] = S[:, None, 1]
    out[:, :, 0, 2] = S[:, None, 2]
    out[:, :, 1:, 0] = S[:, None, None, 0] + dx
    out[:, :, 1:, 1] = S[:, None, None, 1] + dy
    out[:, :, 1:, 2] = S[:, None, None, 2] + dz
    return out


def backup_ok(S, H=10, safeR=None):
    """Vong luon du phong: quay cuc dai theo mot trong hai chieu va san bang goc quy dao.

    S co dang (N, 5). Tra ve (N,) bang True neu it nhat mot chieu luon an toan trong H buoc.
    """
    if safeR is None:
        safeR = CFG["safeR"]
    T = backup_traj(S, H)                      # (N, 2, H+1, 3)
    ok = seg_ok_v(T[:, :, :-1, :], T[:, :, 1:, :], safeR, _TAU2)   # (N, 2, H)
    return ok.all(axis=2).any(axis=1)


def shield(s, H=10, safeR=None):
    """Tap hanh dong duoc phep: mot buoc an toan va con vong luon du phong."""
    S = np.asarray(s, dtype=np.float64)[None, :]
    m1, SN = onestep(S, safeR)
    idx = np.nonzero(m1[0])[0]
    if idx.size == 0:
        return np.array([4]), SN[0], False
    good = idx[backup_ok(SN[0, idx], H, safeR)]
    if good.size == 0:
        return idx, SN[0], False
    return good, SN[0], True


# ============ 2. HAI CACH BIEU DIEN HAM GIA TRI ============
ANG = [(6, 3), (6, 3), (8, 3), (8, 3), (10, 3), (12, 5), (16, 5)]
DMAX = 5


class UniformQ:
    kind = "uniform"

    def __init__(self, n, nz, npsi, ngam):
        self.n, self.nz, self.npsi, self.ngam = n, nz, npsi, ngam
        self.hx = CFG["Lx"] / n
        self.hz = (CFG["Zmax"] - CFG["Zmin"]) / nz
        self.Q = np.zeros((n, n, nz, npsi, ngam, NACT), dtype=np.float32)
        self.diam = math.sqrt(2 * self.hx ** 2 + self.hz ** 2)

    def idx(self, s):
        x, y, z, ps, gm = s
        i = min(self.n - 1, max(0, int(x / self.hx)))
        j = min(self.n - 1, max(0, int(y / self.hx)))
        k = min(self.nz - 1, max(0, int((z - CFG["Zmin"]) / self.hz)))
        p = int((ps + math.pi) / (2 * math.pi) * self.npsi) % self.npsi
        g = min(self.ngam - 1, max(0, int((gm + CFG["gmax"])
                                          / (2 * CFG["gmax"] + 1e-9) * self.ngam)))
        return (i, j, k, p, g)

    def q(self, key):
        return self.Q[key]

    def add(self, key, a, dq):
        self.Q[key][a] += dq

    def note(self, key, td, y):
        pass

    def nparams(self):
        return int(self.Q.size)

    def nleaf(self):
        return int(self.Q.size // NACT)


def _cell_geo(d, i, j, k):
    n = 1 << d
    hx = CFG["Lx"] / n
    hz = (CFG["Zmax"] - CFG["Zmin"]) / n
    return hx, hz, math.sqrt(2 * hx * hx + hz * hz)


def _risk_span(cell):
    """Bien thien cua truong khoang ho ben trong mot o, lay tren luoi 3 x 3 x 3."""
    d, i, j, k = cell
    hx, hz, diam = _cell_geo(d, i, j, k)
    t = np.array([0.15, 0.5, 0.85])
    X = (i + t) * hx
    Y = (j + t) * hx
    Z = CFG["Zmin"] + (k + t) * hz
    G = np.stack(np.meshgrid(X, Y, Z, indexing="ij"), axis=-1).reshape(-1, 3)
    c = clear_v(G)
    return float(c.max() - c.min()), diam


class AdaptiveQ:
    """Cay bat phan tren (x, y, z), phan giai goc tang dan theo muc sau.

    crit chon dai luong dieu khien viec tinh chia:
      value - do tan cua muc tieu bootstrap trong o (de xuat)
      td    - trung binh truot cua tri tuyet doi sai so thoi gian
      risk  - bien thien cua truong khoang ho trong o
      mix   - tich cua do tan gia tri voi he so rui ro
    """
    kind = "adaptive"

    def __init__(self, crit="value", tau=1.6, nmin=800, d0=3, dmax=DMAX,
                 budget=700000, warm=40):
        self.crit, self.tau, self.nmin = crit, tau, nmin
        self.d0, self.dmax, self.budget, self.warm = d0, dmax, budget, warm
        self.split = set()
        self.leaf = {}
        self.st = {}            # cell -> [visits, ema|td|, ey, ey2, risk, diam]
        self._np = 0
        self._sbar = 0.0
        self._nchk = 0
        n0 = 1 << d0
        npsi, ngam = ANG[d0]
        for i in range(n0):
            for j in range(n0):
                for k in range(n0):
                    cell = (d0, i, j, k)
                    self.leaf[cell] = np.zeros((npsi, ngam, NACT), dtype=np.float32)
                    self._reset(cell)
                    self._np += npsi * ngam * NACT
        for d in range(d0):
            nn = 1 << d
            for i in range(nn):
                for j in range(nn):
                    for k in range(nn):
                        self.split.add((d, i, j, k))

    def _reset(self, cell):
        rs, diam = _risk_span(cell)
        self.st[cell] = [0, 0.0, 0.0, 0.0, rs, diam]

    def _cell(self, x, y, z):
        d, i, j, k = 0, 0, 0, 0
        while (d, i, j, k) in self.split:
            d += 1
            n = 1 << d
            hx = CFG["Lx"] / n
            hz = (CFG["Zmax"] - CFG["Zmin"]) / n
            i = min(n - 1, max(0, int(x / hx)))
            j = min(n - 1, max(0, int(y / hx)))
            k = min(n - 1, max(0, int((z - CFG["Zmin"]) / hz)))
        return (d, i, j, k)

    def idx(self, s):
        x, y, z, ps, gm = s
        c = self._cell(x, y, z)
        npsi, ngam = ANG[c[0]]
        p = int((ps + math.pi) / (2 * math.pi) * npsi) % npsi
        g = min(ngam - 1, max(0, int((gm + CFG["gmax"])
                                     / (2 * CFG["gmax"] + 1e-9) * ngam)))
        return (c, p, g)

    def q(self, key):
        return self.leaf[key[0]][key[1], key[2]]

    def add(self, key, a, dq):
        self.leaf[key[0]][key[1], key[2], a] += dq

    def score(self, cell):
        n, etd, ey, ey2, rs, diam = self.st[cell]
        sd = math.sqrt(max(ey2 - ey * ey, 0.0))
        if self.crit == "td":
            return etd
        if self.crit == "risk":
            return rs / diam
        if self.crit == "mix":
            return sd * (1.0 + rs / diam)
        return sd

    def note(self, key, td, y):
        cell = key[0]
        st = self.st[cell]
        st[0] += 1
        st[1] += 0.005 * (abs(td) - st[1])
        yc = max(-300.0, min(300.0, y))
        st[2] += 0.005 * (yc - st[2])
        st[3] += 0.005 * (yc * yc - st[3])
        if st[0] < self.nmin or cell[0] >= self.dmax:
            return
        sc = self.score(cell)
        self._nchk += 1
        self._sbar += 0.02 * (sc - self._sbar)
        if self._nchk <= self.warm:
            st[0] = self.nmin // 2
            return
        if sc > self.tau * self._sbar:
            self._split(cell)
        else:
            st[0] = self.nmin // 2

    def _split(self, cell):
        d, i, j, k = cell
        npc, ngc = ANG[d + 1]
        cur = self.leaf[cell].size
        if self._np - cur + 8 * npc * ngc * NACT > self.budget:
            self.st[cell][0] = self.nmin // 2
            return
        Qp = self.leaf.pop(cell)
        self.st.pop(cell)
        self._np += 8 * npc * ngc * NACT - cur
        self.split.add(cell)
        op, og = Qp.shape[0], Qp.shape[1]
        rep = np.empty((npc, ngc, NACT), dtype=np.float32)
        for a in range(npc):
            for b in range(ngc):
                rep[a, b] = Qp[int(a * op / npc) % op, min(og - 1, int(b * og / ngc))]
        for di in (0, 1):
            for dj in (0, 1):
                for dk in (0, 1):
                    ck = (d + 1, 2 * i + di, 2 * j + dj, 2 * k + dk)
                    self.leaf[ck] = rep.copy()
                    self._reset(ck)

    def nparams(self):
        return int(self._np)

    def nleaf(self):
        return len(self.leaf)


# ============ 3. HUAN LUYEN VA DANH GIA ============
GX, GY, GZ = CFG["goal"]
S0 = (CFG["start"][0], CFG["start"][1], CFG["start"][2], CFG["psi0"], CFG["gam0"])


H_BACKUP = 10


def mask2(S):
    """Tap hanh dong duoc bo loc cho phep tai mot trang thai."""
    return shield(S, H_BACKUP)


def train(rep, episodes, seed=2026, track=0, log=None):
    rng = np.random.default_rng(seed)
    eps, alr = CFG["eps0"], CFG["alpha0"]
    succ = np.zeros(episodes); coll = np.zeros(episodes); steps = np.zeros(episodes)
    dead = 0
    grow = []
    t0 = time.time()
    for ep in range(episodes):
        s = np.array(S0, dtype=np.float64)
        feas, SN, ok = mask2(s)
        if not ok:
            dead += 1
        dprev = math.dist(tuple(s[:3]), (GX, GY, GZ))
        hit = reach = False
        t = 0
        for t in range(1, CFG["Tmax"] + 1):
            key = rep.idx(s)
            if rng.random() < eps:
                a = int(feas[rng.integers(feas.size)])
            else:
                qq = rep.q(key)[feas]
                m = qq.max()
                cand = feas[qq >= m - 1e-9]
                a = int(cand[rng.integers(cand.size)]) if cand.size > 1 else int(cand[0])
            sn = SN[a]
            seg = np.stack([s[:3], sn[:3]])
            bad = not _ok0(s, sn)
            r = (-CFG["lam"] - CFG["turn_pen"] * abs(np.repeat([-1., 0., 1.], 3)[a])
                 - CFG["clb_pen"] * abs(np.tile([-1., 0., 1.], 3)[a]))
            done = False
            if bad:
                r = CFG["R_hit"]; done = True; hit = True
            else:
                dnow = math.dist(tuple(sn[:3]), (GX, GY, GZ))
                r += CFG["beta"] * (dprev - dnow)
                dprev = dnow
                if dnow <= CFG["goal_rad"]:
                    r = CFG["R_goal"]; done = True; reach = True
            if (not done) and t == CFG["Tmax"]:
                r += CFG["R_timeout"]; done = True
            if done:
                y = r
            else:
                fn, SN2, ok2 = mask2(sn)
                if not ok2:
                    dead += 1
                kn = rep.idx(sn)
                y = r + CFG["gamma"] * float(rep.q(kn)[fn].max())
            td = y - rep.q(key)[a]
            rep.add(key, a, alr * td)
            rep.note(key, td, y)
            if done:
                break
            s, feas, SN = sn, fn, SN2
        succ[ep] = 1.0 if reach else 0.0
        coll[ep] = 1.0 if hit else 0.0
        steps[ep] = t
        eps = max(CFG["eps_min"], eps * CFG["eps_decay"])
        alr = max(CFG["alpha_min"], alr * CFG["alpha_decay"])
        if track and (ep + 1) % track == 0:
            grow.append((ep + 1, rep.nparams()))
        if log and (ep + 1) % log == 0:
            print("      ep %5d succ=%.3f coll=%.3f p=%d"
                  % (ep + 1, succ[max(0, ep - 499):ep + 1].mean(),
                     coll[max(0, ep - 499):ep + 1].mean(), rep.nparams()), flush=True)
    return dict(succ=succ, coll=coll, steps=steps, grow=grow, dead=dead,
                wall=time.time() - t0)


_TAU = np.array([0.25, 0.5, 0.75, 1.0])


def _ok0(s, sn):
    P = s[:3] + (sn[:3] - s[:3])[None, :] * _TAU[:, None]
    if (P[:, 0] < 0).any() or (P[:, 0] > CFG["Lx"]).any() \
            or (P[:, 1] < 0).any() or (P[:, 1] > CFG["Ly"]).any() \
            or (P[:, 2] < CFG["Zmin"]).any() or (P[:, 2] > CFG["Zmax"]).any():
        return False
    return bool((clear_v(P) > 0.0).all())


def rollout(rep, Tmax=420):
    s = np.array(S0, dtype=np.float64)
    P = [s[:3].copy()]
    mc = clearance(*s[:3])
    hit = False
    for _ in range(Tmax):
        feas, SN, _ = mask2(s)
        qq = rep.q(rep.idx(s))[feas]
        a = int(feas[int(np.argmax(qq))])
        sn = SN[a]
        if not _ok0(s, sn):
            hit = True
        s = sn
        P.append(s[:3].copy())
        mc = min(mc, clearance(*s[:3]))
        if hit:
            break
        if math.dist(tuple(s[:3]), (GX, GY, GZ)) <= CFG["goal_rad"]:
            break
    P = np.array(P)
    reached = math.dist(tuple(P[-1]), (GX, GY, GZ)) <= CFG["goal_rad"] and not hit
    return dict(path=P, hit=hit, reached=reached,
                length=float(np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1))),
                minclear=float(mc))


# ============ 4. CAC THI NGHIEM ============
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figs", "p2b")
os.makedirs(OUT, exist_ok=True)
EP = 6000
H_BACKUP = 17


def _mk(spec):
    k = spec["kind"]
    if k == "uniform":
        return UniformQ(spec["n"], spec["nz"], spec["npsi"], spec["ngam"])
    return AdaptiveQ(crit=spec.get("crit", "value"), tau=spec.get("tau", 1.6),
                          nmin=spec.get("nmin", 800), budget=spec.get("budget", 700000))


def run(job, spec, episodes=EP, track=250):
    rep = _mk(spec)
    d = train(rep, episodes, track=track, log=1000)
    ro = rollout(rep)
    r = dict(job=job, spec=spec, episodes=episodes,
             params=rep.nparams(), leaf=rep.nleaf(),
             succ=float(d["succ"][-1000:].mean()), coll=float(d["coll"][-1000:].mean()),
             dead=int(d["dead"]), wall=float(d["wall"]),
             steps=float(d["steps"][-1000:].mean()),
             reach=bool(ro["reached"]), hit=bool(ro["hit"]),
             length=float(ro["length"]), minclear=float(ro["minclear"]),
             curve_succ=[float(v) for v in d["succ"].reshape(-1, 100).mean(1)],
             curve_coll=[float(v) for v in d["coll"].reshape(-1, 100).mean(1)],
             grow=[[int(a), int(b)] for a, b in d["grow"]],
             path=ro["path"].tolist())
    if spec["kind"] == "adaptive":
        r["cells"] = [[int(c) for c in cell] for cell in rep.leaf]
    with open(os.path.join(OUT, job + ".json"), "w") as f:
        json.dump(r, f)
    print("== %s  p=%d succ=%.3f coll=%.3f L=%s mc=%.2f  %.0fs"
          % (job, r["params"], r["succ"], r["coll"],
             ("%.1f" % r["length"]) if r["reach"] else "-", r["minclear"], r["wall"]), flush=True)
    return r


JOBS = {
    "u08": dict(kind="uniform", n=8, nz=4, npsi=6, ngam=3),
    "u12": dict(kind="uniform", n=12, nz=6, npsi=6, ngam=3),
    "u16": dict(kind="uniform", n=16, nz=6, npsi=8, ngam=3),
    "u20": dict(kind="uniform", n=20, nz=8, npsi=8, ngam=3),
    "u24": dict(kind="uniform", n=24, nz=10, npsi=8, ngam=3),
    "u32": dict(kind="uniform", n=32, nz=12, npsi=10, ngam=5),
    "a_value": dict(kind="adaptive", crit="value", tau=1.6),
    "a_td": dict(kind="adaptive", crit="td", tau=1.6),
    "a_risk": dict(kind="adaptive", crit="risk", tau=1.6),
    "a_mix": dict(kind="adaptive", crit="mix", tau=1.6),
    "a_tau08": dict(kind="adaptive", crit="value", tau=0.8),
    "t_tau08": dict(kind="adaptive", crit="td", tau=0.8),
    "t_tau12": dict(kind="adaptive", crit="td", tau=1.2),
    "t_tau24": dict(kind="adaptive", crit="td", tau=2.4),
    "t_tau32": dict(kind="adaptive", crit="td", tau=3.2),
    "a_tau24": dict(kind="adaptive", crit="value", tau=2.4),
    "a_tau32": dict(kind="adaptive", crit="value", tau=3.2),
}



# ============ 5. HINH VE ============
RES = OUT
FIG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figs", "p2")

CM = 1.0 / 2.54
from matplotlib import font_manager as _fm
_FONTS = set(f.name for f in _fm.fontManager.ttflist)
SERIF = next((f for f in ("Times New Roman", "Liberation Serif", "Nimbus Roman") if f in _FONTS),
             "DejaVu Serif")
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': [SERIF, 'Liberation Serif', 'DejaVu Serif'],
    'mathtext.fontset': 'custom', 'mathtext.rm': SERIF, 'mathtext.it': SERIF + ':italic',
    'mathtext.bf': SERIF + ':bold', 'mathtext.cal': SERIF + ':italic',
    'font.size': 10, 'axes.labelsize': 10, 'axes.titlesize': 9.5,
    'xtick.labelsize': 9, 'ytick.labelsize': 9, 'axes.linewidth': 0.8,
    'lines.linewidth': 1.4, 'legend.fontsize': 8.0, 'savefig.dpi': 600, 'figure.dpi': 110,
})
OK = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#000000']
LANG = "en"


def L(en, vi):
    return vi if LANG == "vi" else en


def load():
    R = {}
    for f in glob.glob(os.path.join(RES, "*.json")):
        d = json.load(open(f))
        R[d["job"]] = d
    return R


def uname(r):
    s = r["spec"]
    return "%d×%d×%d×%d×%d" % (s["n"], s["n"], s["nz"], s["npsi"], s["ngam"])


def save(fig, name):
    d = os.path.join(FIG, LANG)
    os.makedirs(d, exist_ok=True)
    fig.savefig(os.path.join(d, name), bbox_inches=None, pad_inches=0.0)
    plt.close(fig)
    print("  luu %s/%s" % (LANG, name))


def ep90(r, lvl=0.9):
    cs = r["curve_succ"]
    for i, v in enumerate(cs):
        if v >= lvl:
            return (i + 1) * 100
    return None


# ---------------- hinh 2: lat cat phan hoach ----------------
def fig_partition(R, job="a_td", zcut=31.5, name="Fig2_partition.png"):
    fig, ax = plt.subplots(figsize=(8.6 * CM, 9.2 * CM))
    cells = R[job]["cells"]
    Lz = CFG["Zmax"] - CFG["Zmin"]
    depth_count = {}
    for d, i, j, k in cells:
        n = 1 << d
        hz = Lz / n
        z0 = CFG["Zmin"] + k * hz
        if not (z0 <= zcut < z0 + hz):
            continue
        hx = CFG["Lx"] / n
        depth_count[d] = depth_count.get(d, 0) + 1
        ax.add_patch(plt.Rectangle((i * hx, j * hx), hx, hx, fc='none', ec='#5D6D7E', lw=0.35))
    th = np.linspace(0, 2 * np.pi, 90)
    first = True
    for cx, cy, cz, R_, kind in THREATS:
        r = None
        if kind == 1 and zcut <= 2 * cz:
            r = R_
        elif kind == 0 and abs(zcut - cz) < R_:
            r = math.sqrt(R_ * R_ - (zcut - cz) ** 2)
        if r is None:
            continue
        ax.fill(cx + r * np.cos(th), cy + r * np.sin(th), color='#D55E00', alpha=0.35,
                ec='#8c3d00', lw=0.8, label=L('Threat section', 'Mặt cắt vùng nguy hiểm') if first else None)
        first = False
    P = np.array(R[job]["path"])
    ax.plot(P[:, 0], P[:, 1], '-', color=OK[0], lw=1.3,
            label=L('Greedy track, projected', 'Tuyến tham lam, hình chiếu'))
    ax.plot(CFG["start"][0], CFG["start"][1], 's', color='#009E73', ms=6, mec='k', mew=0.6,
            label=L('Start', 'Điểm xuất phát'))
    ax.plot(CFG["goal"][0], CFG["goal"][1], '*', color='#CC0000', ms=11, mec='k', mew=0.5,
            label=L('Goal', 'Điểm đích'))
    ax.set_xlim(0, CFG["Lx"]); ax.set_ylim(0, CFG["Ly"]); ax.set_aspect('equal')
    ax.set_xlabel('x (m)'); ax.set_ylabel('y (m)')
    h, lb = ax.get_legend_handles_labels()
    fig.legend(h, lb, loc='lower center', ncol=2, fontsize=7.2, framealpha=1.0,
               borderaxespad=0.2, bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.35, rect=(0.0, 0.12, 1.0, 1.0))
    save(fig, name)
    return depth_count


# ---------------- hinh 3: duong cong huan luyen ----------------
def fig_learning(R, name="Fig3_learning.png", blk=3):
    fig, axs = plt.subplots(1, 2, figsize=(14.8 * CM, 6.8 * CM))
    jobs = [("u12", '--'), ("u20", '-.'), ("u32", ':'), ("a_td", '-')]
    for k, (j, ls) in enumerate(jobs):
        r = R[j]
        lab = (L('Uniform ', 'Lưới đều ') + uname(r)) if r["spec"]["kind"] == "uniform" \
            else L('Proposed octree', 'Cây bát phân đề xuất')
        for ax, key in zip(axs, ("curve_succ", "curve_coll")):
            y = np.array(r[key])
            m = len(y) // blk * blk
            ym = y[:m].reshape(-1, blk).mean(1)
            x = (np.arange(len(ym)) + 1) * 100 * blk
            ax.plot(x, 100 * ym, ls, color=OK[k], label=lab)
    axs[0].set_ylabel(L('Success rate (%)', 'Tỷ lệ thành công (%)'))
    axs[1].set_ylabel(L('Collision rate (%)', 'Tỷ lệ va chạm (%)'))
    for ax in axs:
        ax.set_xlabel(L('Training episode', 'Tập huấn luyện'))
        ax.grid(True, alpha=0.3, ls=':')
    axs[0].set_ylim(-3, 103)
    h, lb = axs[0].get_legend_handles_labels()
    fig.legend(h, lb, loc='lower center', ncol=4, fontsize=7.2, framealpha=1.0,
               borderaxespad=0.2, handlelength=2.2, columnspacing=1.0,
               bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.4, rect=(0.0, 0.10, 1.0, 1.0))
    save(fig, name)


# ---------------- hinh 4: tang truong bo nho ----------------
def fig_growth(R, name="Fig4_growth.png"):
    fig, ax = plt.subplots(figsize=(8.6 * CM, 6.2 * CM))
    for k, (j, tau) in enumerate((("t_tau08", 0.8), ("a_td", 1.6), ("t_tau24", 2.4),
                                  ("t_tau32", 3.2))):
        g = np.array(R[j]["grow"])
        ax.plot(g[:, 0], g[:, 1] / 1e3, ['-', '--', '-.', ':'][k], color=OK[k],
                label=r'$\tau=%.1f$' % tau if LANG == "en" else (r'$\tau=%s$' % ('%.1f' % tau).replace('.', '{,}')))
    ax.hlines(700, 1550, 6150, color='0.35', lw=0.9, ls='--')
    ax.text(5950, 650, L('memory budget', 'ngân sách bộ nhớ'), fontsize=7.6, color='0.3',
            ha='right', va='top')
    ax.set_xlabel(L('Training episode', 'Tập huấn luyện'))
    ax.set_ylabel(L('Stored action values (thousands)', 'Số giá trị hành động (nghìn)'))
    ax.set_ylim(0, 800); ax.set_xlim(0, 6200)
    ax.grid(True, alpha=0.3, ls=':')
    ax.legend(loc='upper left', fontsize=7.4, framealpha=0.95, bbox_to_anchor=(0.01, 0.99))
    fig.tight_layout(pad=0.4)
    save(fig, name)


# ---------------- hinh 5: quy dao ba chieu ----------------
def fig_traj(R, name="Fig5_traj3d.png"):
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
    fig = plt.figure(figsize=(12.0 * CM, 9.6 * CM))
    ax = fig.add_subplot(111, projection='3d')
    u = np.linspace(0, 2 * np.pi, 28)
    for cx, cy, cz, R_, kind in THREATS:
        if kind == 0:
            v = np.linspace(0, np.pi, 14)
            X = cx + R_ * np.outer(np.cos(u), np.sin(v))
            Y = cy + R_ * np.outer(np.sin(u), np.sin(v))
            Z = cz + R_ * np.outer(np.ones_like(u), np.cos(v))
        else:
            zz = np.linspace(CFG["Zmin"], min(2 * cz, CFG["Zmax"]), 8)
            X = cx + R_ * np.outer(np.cos(u), np.ones_like(zz))
            Y = cy + R_ * np.outer(np.sin(u), np.ones_like(zz))
            Z = np.outer(np.ones_like(u), zz)
        ax.plot_surface(X, Y, Z, color='#D55E00', alpha=0.16, lw=0, shade=False)
    for k, (j, ls) in enumerate((("u24", '--'), ("a_td", '-'))):
        P = np.array(R[j]["path"])
        lab = (L('Uniform ', 'Lưới đều ') + uname(R[j])) if R[j]["spec"]["kind"] == "uniform" \
            else L('Proposed octree', 'Cây bát phân đề xuất')
        ax.plot(P[:, 0], P[:, 1], P[:, 2], ls, color=[OK[1], OK[0]][k], lw=1.6, label=lab)
    ax.scatter(*CFG["start"], marker='s', s=26, color='#009E73', edgecolor='k')
    ax.scatter(*CFG["goal"], marker='*', s=70, color='#CC0000', edgecolor='k')
    ax.set_xlabel('x (m)', labelpad=2); ax.set_ylabel('y (m)', labelpad=2)
    ax.set_zlabel('z (m)', labelpad=2)
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.set_zlim(0, 45)
    ax.view_init(elev=26, azim=-58)
    ax.tick_params(labelsize=7.5, pad=0)
    fig.legend(loc='lower center', ncol=2, fontsize=7.6, framealpha=1.0,
               bbox_to_anchor=(0.5, 0.0))
    fig.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.10)
    save(fig, name)


# ---------------- hinh 6: bien Pareto ----------------
def fig_pareto(R, name="Fig6_pareto.png"):
    fig, axs = plt.subplots(1, 2, figsize=(14.8 * CM, 6.8 * CM))
    U = sorted([R[j] for j in ("u08", "u12", "u16", "u20", "u24", "u32")],
               key=lambda r: r["params"])
    A = [R[j] for j in ("t_tau08", "a_td", "t_tau24", "t_tau32")]
    up = [r["params"] / 1e3 for r in U]
    ul = [r["length"] if r["reach"] else np.nan for r in U]
    ue = [ep90(r) if ep90(r) else np.nan for r in U]
    axs[0].plot(up, ul, '-o', color=OK[1], ms=4, label=L('Uniform grids', 'Lưới đều'))
    axs[0].plot([r["params"] / 1e3 for r in A], [r["length"] for r in A], 's', color=OK[0],
                ms=5.5, label=L('Proposed octree', 'Cây bát phân đề xuất'))
    axs[1].plot(up, ue, '-o', color=OK[1], ms=4, label=L('Uniform grids', 'Lưới đều'))
    axs[1].plot([r["params"] / 1e3 for r in A], [ep90(r) for r in A], 's', color=OK[0],
                ms=5.5, label=L('Proposed octree', 'Cây bát phân đề xuất'))
    u32 = R["u32"]
    axs[1].plot([u32["params"] / 1e3], [4000], 'o', mfc='white', mec=OK[1], ms=5.5, mew=1.2)
    axs[1].text(u32["params"] / 1e3 / 1.35, 4000,
                L('finest grid: never reaches 90%', 'lưới mịn nhất: không đạt 90%'),
                fontsize=7.2, ha='right', va='center', color='0.25')
    axs[0].set_ylabel(L('Greedy path length (m)', 'Chiều dài tuyến tham lam (m)'))
    axs[1].set_ylabel(L('Episodes to 90% success', 'Số tập để đạt 90% thành công'))
    axs[1].set_ylim(1200, 4250)
    for ax in axs:
        ax.set_xscale('log')
        ax.set_xlim(25, 9000)
        ax.set_xlabel(L('Stored action values (thousands)', 'Số giá trị hành động (nghìn)'))
        ax.grid(True, alpha=0.3, ls=':')
    h, lb = axs[0].get_legend_handles_labels()
    fig.legend(h, lb, loc='lower center', ncol=2, fontsize=7.6, framealpha=1.0,
               borderaxespad=0.2, bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.4, rect=(0.0, 0.11, 1.0, 1.0))
    save(fig, name)


# ---------------- hinh 7: so sanh tieu chi tinh chia ----------------
def fig_criteria(R, name="Fig7_criteria.png"):
    jobs = ("a_td", "a_value", "a_mix", "a_risk")
    lab = {"a_td": L('TD\nerror', 'Sai số\nthời gian'),
           "a_value": L('Target\nspread', 'Độ tản\nmục tiêu'),
           "a_mix": L('Spread\n× risk', 'Độ tản\n× rủi ro'),
           "a_risk": L('Clearance\nspan', 'Biến thiên\nkhoảng hở')}
    fig, axs = plt.subplots(1, 2, figsize=(14.8 * CM, 6.2 * CM))
    xp = np.arange(len(jobs))
    p = [R[j]["params"] / 1e3 for j in jobs]
    l_ = [R[j]["length"] for j in jobs]
    axs[0].bar(xp, p, 0.55, color=OK[0], ec='k', lw=0.5)
    axs[1].bar(xp, l_, 0.55, color=OK[2], ec='k', lw=0.5)
    for i in range(len(jobs)):
        axs[0].text(xp[i], p[i] + 12, '%.0f' % p[i], ha='center', fontsize=7.6)
        axs[1].text(xp[i], l_[i] + 4, '%.0f' % l_[i], ha='center', fontsize=7.6)
    axs[0].set_ylabel(L('Stored action values (thousands)', 'Số giá trị hành động (nghìn)'))
    axs[1].set_ylabel(L('Greedy path length (m)', 'Chiều dài tuyến tham lam (m)'))
    axs[0].set_ylim(0, 700); axs[1].set_ylim(0, 260)
    for ax in axs:
        ax.set_xticks(xp)
        ax.set_xticklabels([lab[j] for j in jobs], fontsize=7.4)
        ax.grid(True, axis='y', alpha=0.3, ls=':')
    fig.tight_layout(pad=0.4)
    save(fig, name)


def render_all(lang):
    global LANG
    LANG = lang
    R = load()
    dc = fig_partition(R)
    fig_learning(R)
    fig_growth(R)
    fig_traj(R)
    fig_pareto(R)
    fig_criteria(R)
    LANG = "en"
    return dc






# ============ 7. THI NGHIEM VONG PHAN BIEN ============
import os
import sys
import json
import math
import time
import pickle
import heapq
import numpy as np

P = sys.modules[__name__]

OUTR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figs", "p2r")
os.makedirs(OUTR, exist_ok=True)

# ---------------------------------------------------------------- ban do
MAP_M = list(P.THREATS)                                    # ban do goc, 12 vung nguy hiem
MAP_S = [MAP_M[i] for i in (0, 3, 5, 6, 8, 10)]            # 6 vung nguy hiem
MAP_D = MAP_M + [                                          # 20 vung, 8 tru cao 40 m
    (46.0, 36.0, 20.0, 6.0, 1), (62.0, 48.0, 20.0, 6.0, 1),
    (30.0, 50.0, 20.0, 6.0, 1), (52.0, 70.0, 20.0, 6.0, 1),
    (80.0, 56.0, 20.0, 5.0, 1), (16.0, 40.0, 20.0, 5.0, 1),
    (42.0, 84.0, 20.0, 5.0, 1), (78.0, 28.0, 20.0, 5.0, 1),
]
MAPS = {"S": MAP_S, "M": MAP_M, "D": MAP_D}


def set_map(name):
    T = np.array(MAPS[name], dtype=np.float64)
    P.THREATS = list(MAPS[name])
    P.TCX, P.TCY, P.TCZ, P.TR, P.TK = T[:, 0], T[:, 1], T[:, 2], T[:, 3], T[:, 4]
    P._SPH = P.TK == 0


# ---------------------------------------------------------------- luat tinh chia doi chung
class CountQ(P.AdaptiveQ):
    """Tach khi so lan ghe vuot N_min * 4^(D - D0), khong nhin vao tin hieu hoc
    (ban kinh tin cay ti le voi duong kinh o, nhu cac so do co bao dam regret)."""

    def note(self, key, td, y):
        cell = key[0]
        st = self.st[cell]
        st[0] += 1
        st[1] += 0.005 * (abs(td) - st[1])
        if cell[0] >= self.dmax:
            return
        if st[0] >= self.nmin * 4 ** (cell[0] - self.d0):
            self._split(cell)


class AbsQ(P.AdaptiveQ):
    """Tach khi trung binh truot |zeta| vuot mot nguong tuyet doi theta (co don vi phan thuong)."""

    def __init__(self, theta, **kw):
        super().__init__(**kw)
        self.theta = theta

    def note(self, key, td, y):
        cell = key[0]
        st = self.st[cell]
        st[0] += 1
        st[1] += 0.005 * (abs(td) - st[1])
        if st[0] < self.nmin or cell[0] >= self.dmax:
            return
        if st[1] > self.theta:
            self._split(cell)
        else:
            st[0] = self.nmin // 2


# ---------------------------------------------------------------- huan luyen co ghi chep
def train_log(rep, episodes, seed=2026, track=250, rscale=1.0, gtrack=250):
    """Ban sao nguyen van cua P.train, them ghi chep thu dong va he so nhan phan thuong."""
    C = P.CFG
    rng = np.random.default_rng(seed)
    eps, alr = C["eps0"], C["alpha0"]
    succ = np.zeros(episodes); coll = np.zeros(episodes); steps = np.zeros(episodes)
    tdm = np.zeros(episodes)
    dead = 0
    grow, glen, sbar = [], [], []
    t0 = time.time()
    GX, GY, GZ = C["goal"]
    lam, tp, cp = C["lam"] * rscale, C["turn_pen"] * rscale, C["clb_pen"] * rscale
    Rhit, Rgoal, Rto, beta = C["R_hit"] * rscale, C["R_goal"] * rscale, \
        C["R_timeout"] * rscale, C["beta"] * rscale
    for ep in range(episodes):
        s = np.array(P.S0, dtype=np.float64)
        feas, SN, ok = P.mask2(s)
        if not ok:
            dead += 1
        dprev = math.dist(tuple(s[:3]), (GX, GY, GZ))
        hit = reach = False
        t = 0
        sabs = 0.0
        for t in range(1, C["Tmax"] + 1):
            key = rep.idx(s)
            if rng.random() < eps:
                a = int(feas[rng.integers(feas.size)])
            else:
                qq = rep.q(key)[feas]
                m = qq.max()
                cand = feas[qq >= m - 1e-9]
                a = int(cand[rng.integers(cand.size)]) if cand.size > 1 else int(cand[0])
            sn = SN[a]
            bad = not P._ok0(s, sn)
            r = (-lam - tp * abs(np.repeat([-1., 0., 1.], 3)[a])
                 - cp * abs(np.tile([-1., 0., 1.], 3)[a]))
            done = False
            if bad:
                r = Rhit; done = True; hit = True
            else:
                dnow = math.dist(tuple(sn[:3]), (GX, GY, GZ))
                r += beta * (dprev - dnow)
                dprev = dnow
                if dnow <= C["goal_rad"]:
                    r = Rgoal; done = True; reach = True
            if (not done) and t == C["Tmax"]:
                r += Rto; done = True
            if done:
                y = r
            else:
                fn, SN2, ok2 = P.mask2(sn)
                if not ok2:
                    dead += 1
                kn = rep.idx(sn)
                y = r + C["gamma"] * float(rep.q(kn)[fn].max())
            td = y - rep.q(key)[a]
            rep.add(key, a, alr * td)
            rep.note(key, td, y)
            sabs += abs(float(td))
            if done:
                break
            s, feas, SN = sn, fn, SN2
        succ[ep] = 1.0 if reach else 0.0
        coll[ep] = 1.0 if hit else 0.0
        steps[ep] = t
        tdm[ep] = sabs / max(t, 1) / rscale
        eps = max(C["eps_min"], eps * C["eps_decay"])
        alr = max(C["alpha_min"], alr * C["alpha_decay"])
        if track and (ep + 1) % track == 0:
            grow.append((ep + 1, rep.nparams()))
            sbar.append((ep + 1, float(getattr(rep, "_sbar", 0.0)) / rscale))
        if gtrack and (ep + 1) % gtrack == 0:
            ro = P.rollout(rep)
            glen.append((ep + 1, float(ro["length"]) if ro["reached"] else None))
        if (ep + 1) % 1000 == 0:
            print("      ep %5d succ=%.3f p=%d  %.0fs" % (ep + 1, succ[ep - 999:ep + 1].mean(),
                                                         rep.nparams(), time.time() - t0),
                  flush=True)
    return dict(succ=succ, coll=coll, steps=steps, tdm=tdm, grow=grow, glen=glen, sbar=sbar,
                dead=dead, wall=time.time() - t0)


def make_rep(spec):
    k = spec["kind"]
    if k == "uniform":
        return P.UniformQ(spec["n"], spec["nz"], spec["npsi"], spec["ngam"])
    if k == "count":
        return CountQ(crit="td", tau=1.6, nmin=spec.get("nmin", 800))
    if k == "abs":
        return AbsQ(spec["theta"], crit="td", tau=1.6, nmin=800)
    return P.AdaptiveQ(crit=spec.get("crit", "td"), tau=spec.get("tau", 1.6),
                       nmin=spec.get("nmin", 800), budget=spec.get("budget", 700000))


def run_tab(name, spec, seed=2026, mapname="M", episodes=6000, rscale=1.0, save_q=False):
    set_map(mapname)
    rep = make_rep(spec)
    d = train_log(rep, episodes, seed=seed, rscale=rscale)
    ro = P.rollout(rep)
    cs = d["succ"].reshape(-1, 100).mean(1)
    e90 = next(((i + 1) * 100 for i, v in enumerate(cs) if v >= 0.9), None)
    r = dict(job=name, spec=spec, seed=seed, map=mapname, rscale=rscale, episodes=episodes,
             params=rep.nparams(), leaf=rep.nleaf(),
             succ=float(d["succ"][-1000:].mean()), coll=float(d["coll"][-1000:].mean()),
             dead=int(d["dead"]), wall=float(d["wall"]), ep90=e90,
             reach=bool(ro["reached"]), hit=bool(ro["hit"]),
             length=float(ro["length"]), minclear=float(ro["minclear"]),
             curve_succ=[float(v) for v in cs],
             curve_coll=[float(v) for v in d["coll"].reshape(-1, 100).mean(1)],
             tdm=[float(v) for v in d["tdm"].reshape(-1, 100).mean(1)],
             grow=[[int(a), int(b)] for a, b in d["grow"]],
             sbar=d["sbar"], glen=d["glen"], path=ro["path"].tolist())
    if hasattr(rep, "leaf"):
        r["cells"] = [[int(c) for c in cell] for cell in rep.leaf]
        r["depth"] = {str(k): sum(1 for c in rep.leaf if c[0] == k) for k in range(3, 6)}
    with open(os.path.join(OUTR, name + ".json"), "w") as f:
        json.dump(r, f)
    if save_q:
        with open(os.path.join(OUTR, name + ".pkl"), "wb") as f:
            pickle.dump(rep, f)
    print("== %s p=%d succ=%.3f coll=%.3f e90=%s L=%s mc=%.2f %.0fs" % (
        name, r["params"], r["succ"], r["coll"], e90,
        ("%.1f" % r["length"]) if r["reach"] else "-", r["minclear"], r["wall"]), flush=True)
    return r


# ---------------------------------------------------------------- A* tren cung tap lenh
def astar(mapname="M", res=(2.0, 2.0, 1.0, math.radians(10.0)), maxexp=400_000, wgt=1.0):
    """Tim duong ngan nhat (so buoc) qua cac lenh duoc bo loc (6) cho phep."""
    set_map(mapname)
    C = P.CFG
    G = np.array(C["goal"])
    s0 = np.array(P.S0)
    t0 = time.time()

    def key(s):
        return (int(s[0] / res[0]), int(s[1] / res[1]), int(s[2] / res[2]),
                int(round((s[3] % (2 * math.pi)) / res[3])), int(round(s[4] / P.CFG["gdot"])))

    sl = C["v"] * C["dt"]

    def h(s):
        dxy = math.hypot(s[0] - G[0], s[1] - G[1])
        dz = abs(s[2] - G[2])
        d3 = max(0.0, math.sqrt(dxy * dxy + dz * dz) - C["goal_rad"]) / sl
        dh = max(0.0, dxy - C["goal_rad"]) / (sl * math.cos(C["gmax"]))
        dv = max(0.0, dz - C["goal_rad"]) / (sl * math.sin(C["gmax"]))
        return wgt * max(d3, dh, dv)

    NODES = [tuple(s0)]
    PAR = [-1]
    openl = [(h(s0), 0, 0)]            # (f, -g, indeks nut)
    gbest = {key(s0): 0}
    nexp = 0
    while openl and nexp < maxexp:
        f, g, i = heapq.heappop(openl)
        g = -g
        s = np.array(NODES[i])
        if g > gbest.get(key(s), 1e18):
            continue
        nexp += 1
        if np.linalg.norm(s[:3] - G) <= C["goal_rad"]:
            path = []
            while i >= 0:
                path.append(NODES[i][:3])
                i = PAR[i]
            path = np.array(path[::-1])
            L = float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
            mc = float(P.clear_v(path).min())
            return dict(map=mapname, steps=int(g), length=L, minclear=mc, expanded=nexp, weight=wgt,
                        wall=time.time() - t0, path=path.tolist())
        feas, SN, _ = P.mask2(s)
        for a in feas:
            sn = SN[a]
            if not P._ok0(s, sn):
                continue
            kn = key(sn)
            if g + 1 < gbest.get(kn, 1e18):
                gbest[kn] = g + 1
                NODES.append(tuple(sn))
                PAR.append(i)
                heapq.heappush(openl, (g + 1 + h(sn), -(g + 1), len(NODES) - 1))
    return dict(map=mapname, steps=None, expanded=nexp, wall=time.time() - t0)


# ---------------------------------------------------------------- Double DQN co mat na
class MLP:
    def __init__(self, sizes, rng):
        self.W, self.b = [], []
        for i, o in zip(sizes[:-1], sizes[1:]):
            self.W.append((rng.standard_normal((i, o)) * math.sqrt(2.0 / i)).astype(np.float32))
            self.b.append(np.zeros(o, dtype=np.float32))
        self.m = [np.zeros_like(p) for p in self.W + self.b]
        self.v = [np.zeros_like(p) for p in self.W + self.b]
        self.t = 0

    def fwd(self, X, keep=False):
        H = [X]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            X = X @ W + b
            if i < len(self.W) - 1:
                X = np.maximum(X, 0.0)
            H.append(X)
        return (X, H) if keep else X

    def nparams(self):
        return int(sum(W.size + b.size for W, b in zip(self.W, self.b)))

    def step(self, H, gout, lr):
        gW, gb = [], []
        g = gout
        for i in reversed(range(len(self.W))):
            gW.insert(0, H[i].T @ g)
            gb.insert(0, g.sum(0))
            if i > 0:
                g = (g @ self.W[i].T) * (H[i] > 0)
        self.t += 1
        params = self.W + self.b
        grads = gW + gb
        b1, b2 = 0.9, 0.999
        for j, (p, gr) in enumerate(zip(params, grads)):
            self.m[j] = b1 * self.m[j] + (1 - b1) * gr
            self.v[j] = b2 * self.v[j] + (1 - b2) * gr * gr
            mh = self.m[j] / (1 - b1 ** self.t)
            vh = self.v[j] / (1 - b2 ** self.t)
            p -= (lr * mh / (np.sqrt(vh) + 1e-8)).astype(np.float32)

    def copy_from(self, o):
        self.W = [w.copy() for w in o.W]
        self.b = [b.copy() for b in o.b]


def feat(s):
    C = P.CFG
    return np.array([s[0] / C["Lx"], s[1] / C["Ly"], (s[2] - C["Zmin"]) / (C["Zmax"] - C["Zmin"]),
                     math.sin(s[3]), math.cos(s[3]), s[4] / C["gmax"]], dtype=np.float32)


def run_dqn(name="dqn", seed=2026, mapname="M", episodes=6000, hidden=128, lr=5e-4,
            batch=64, buf=100000, gamma=0.99, tgt=1000, rs=1.0 / 250.0, start=2000):
    set_map(mapname)
    C = P.CFG
    rng = np.random.default_rng(seed)
    net = MLP([6, hidden, hidden, 9], rng)
    tnet = MLP([6, hidden, hidden, 9], rng)
    tnet.copy_from(net)
    Sb = np.zeros((buf, 6), np.float32); S2b = np.zeros((buf, 6), np.float32)
    Ab = np.zeros(buf, np.int64); Rb = np.zeros(buf, np.float32); Db = np.zeros(buf, np.float32)
    Mb = np.zeros((buf, 9), bool)
    nb = 0; ptr = 0; nstep = 0
    eps = C["eps0"]
    succ = np.zeros(episodes); coll = np.zeros(episodes); glen = []
    GX, GY, GZ = C["goal"]
    t0 = time.time()

    def greedy(s, feas):
        q = net.fwd(feat(s)[None, :])[0]
        return int(feas[int(np.argmax(q[feas]))])

    for ep in range(episodes):
        s = np.array(P.S0, dtype=np.float64)
        feas, SN, _ = P.mask2(s)
        dprev = math.dist(tuple(s[:3]), (GX, GY, GZ))
        hit = reach = False
        for t in range(1, C["Tmax"] + 1):
            a = int(feas[rng.integers(feas.size)]) if rng.random() < eps else greedy(s, feas)
            sn = SN[a]
            bad = not P._ok0(s, sn)
            r = (-C["lam"] - C["turn_pen"] * abs(np.repeat([-1., 0., 1.], 3)[a])
                 - C["clb_pen"] * abs(np.tile([-1., 0., 1.], 3)[a]))
            done = False
            if bad:
                r = C["R_hit"]; done = True; hit = True
            else:
                dnow = math.dist(tuple(sn[:3]), (GX, GY, GZ))
                r += C["beta"] * (dprev - dnow)
                dprev = dnow
                if dnow <= C["goal_rad"]:
                    r = C["R_goal"]; done = True; reach = True
            if (not done) and t == C["Tmax"]:
                r += C["R_timeout"]; done = True
            fn = None
            m = np.zeros(9, bool)
            if not done:
                fn, SN2, _ = P.mask2(sn)
                m[fn] = True
            Sb[ptr] = feat(s); S2b[ptr] = feat(sn); Ab[ptr] = a; Rb[ptr] = r * rs
            Db[ptr] = 1.0 if done else 0.0; Mb[ptr] = m
            ptr = (ptr + 1) % buf; nb = min(nb + 1, buf); nstep += 1
            if nb >= start:
                idx = rng.integers(nb, size=batch)
                q, H = net.fwd(Sb[idx], keep=True)
                q2o = net.fwd(S2b[idx]); q2t = tnet.fwd(S2b[idx])
                q2o = np.where(Mb[idx], q2o, -1e9)
                a2 = q2o.argmax(1)
                nxt = q2t[np.arange(batch), a2] * (1.0 - Db[idx])
                y = Rb[idx] + gamma * nxt
                err = q[np.arange(batch), Ab[idx]] - y
                gerr = np.clip(err, -1.0, 1.0) / batch
                gout = np.zeros_like(q)
                gout[np.arange(batch), Ab[idx]] = gerr
                net.step(H, gout, lr)
                if nstep % tgt == 0:
                    tnet.copy_from(net)
            if done:
                break
            s, feas, SN = sn, fn, SN2
        succ[ep] = 1.0 if reach else 0.0
        coll[ep] = 1.0 if hit else 0.0
        eps = max(C["eps_min"], eps * C["eps_decay"])
        if (ep + 1) % 250 == 0:
            ro = rollout_net(net)
            glen.append((ep + 1, ro["length"] if ro["reached"] else None))
        if (ep + 1) % 1000 == 0:
            print("      dqn ep %5d succ=%.3f %.0fs" % (ep + 1, succ[ep - 999:ep + 1].mean(),
                                                        time.time() - t0), flush=True)
    ro = rollout_net(net)
    # thoi gian mot quyet dinh (chi phan tinh mang, khong tinh bo loc)
    X = feat(np.array(P.S0))[None, :]
    tq = time.perf_counter()
    for _ in range(2000):
        net.fwd(X)
    tdec = (time.perf_counter() - tq) / 2000
    cs = succ.reshape(-1, 100).mean(1)
    e90 = next(((i + 1) * 100 for i, v in enumerate(cs) if v >= 0.9), None)
    r = dict(job=name, seed=seed, map=mapname, params=net.nparams(), succ=float(succ[-1000:].mean()),
             coll=float(coll[-1000:].mean()), ep90=e90, reach=bool(ro["reached"]),
             length=float(ro["length"]), minclear=float(ro["minclear"]), wall=time.time() - t0,
             tdec=tdec, nstep=nstep, curve_succ=[float(v) for v in cs],
             curve_coll=[float(v) for v in coll.reshape(-1, 100).mean(1)], glen=glen,
             path=ro["path"].tolist(),
             hyper=dict(hidden=hidden, lr=lr, batch=batch, buf=buf, gamma=gamma, tgt=tgt,
                        rs=rs, start=start))
    with open(os.path.join(OUTR, name + ".json"), "w") as f:
        json.dump(r, f)
    print("== %s p=%d succ=%.3f e90=%s L=%s %.0fs" % (name, r["params"], r["succ"], e90,
          ("%.1f" % r["length"]) if r["reach"] else "-", r["wall"]), flush=True)
    return r


def rollout_net(net, Tmax=420):
    class _R:
        def idx(self, s):
            return s

        def q(self, s):
            return net.fwd(feat(s)[None, :])[0]
    return P.rollout(_R(), Tmax)


# ---------------------------------------------------------------- kiem chung Menh de 1
def frozen_check(name="M_td_s2026", episodes=400, seed=7, eps=0.05, minvis=40):
    """Bang Q dong bang (alpha = 0), chinh sach hanh vi epsilon-tham lam co dinh. Voi moi cap
    (la, lenh) ghi moi muc tieu y, roi so sanh thong ke |zeta| voi nua bien do cua y."""
    with open(os.path.join(OUTR, name + ".pkl"), "rb") as f:
        rep = pickle.load(f)
    set_map("M")
    C = P.CFG
    rng = np.random.default_rng(seed)
    GX, GY, GZ = C["goal"]
    Y = {}
    for ep in range(episodes):
        s = np.array(P.S0, dtype=np.float64)
        feas, SN, _ = P.mask2(s)
        dprev = math.dist(tuple(s[:3]), (GX, GY, GZ))
        for t in range(1, C["Tmax"] + 1):
            key = rep.idx(s)
            if rng.random() < eps:
                a = int(feas[rng.integers(feas.size)])
            else:
                qq = rep.q(key)[feas]
                a = int(feas[int(np.argmax(qq))])
            sn = SN[a]
            bad = not P._ok0(s, sn)
            r = (-C["lam"] - C["turn_pen"] * abs(np.repeat([-1., 0., 1.], 3)[a])
                 - C["clb_pen"] * abs(np.tile([-1., 0., 1.], 3)[a]))
            done = False
            if bad:
                r = C["R_hit"]; done = True
            else:
                dnow = math.dist(tuple(sn[:3]), (GX, GY, GZ))
                r += C["beta"] * (dprev - dnow)
                dprev = dnow
                if dnow <= C["goal_rad"]:
                    r = C["R_goal"]; done = True
            if (not done) and t == C["Tmax"]:
                r += C["R_timeout"]; done = True
            if done:
                y = r
            else:
                fn, SN2, _ = P.mask2(sn)
                y = r + float(rep.q(rep.idx(sn))[fn].max())
            Y.setdefault((key[0], key[1], key[2], a), []).append(y)
            if done:
                break
            s, feas, SN = sn, fn, SN2
    rows = []
    for (cell, p, g, a), ys in Y.items():
        if len(ys) < minvis:
            continue
        ys = np.array(ys)
        q = float(rep.leaf[cell][p, g, a])
        rows.append(dict(depth=cell[0], n=len(ys), etd=float(np.mean(np.abs(ys - q))),
                         mad=float(np.mean(np.abs(ys - ys.mean()))),
                         half=float(0.5 * (ys.max() - ys.min())), bias=float(abs(q - ys.mean()))))
    # thong ke cap la tu luc huan luyen
    leaves = []
    for cell, st in rep.st.items():
        if st[1] <= 0.0:
            continue
        d, i, j, k = cell
        n = 1 << d
        hx = C["Lx"] / n; hz = (C["Zmax"] - C["Zmin"]) / n
        c = np.array([(i + 0.5) * hx, (j + 0.5) * hx, C["Zmin"] + (k + 0.5) * hz])
        leaves.append(dict(cell=list(cell), ebar=float(st[1]), clear=float(P.clear_v(c[None, :])[0]),
                           dgoal=float(np.linalg.norm(c - np.array(C["goal"])))))
    out = dict(rows=rows, leaves=leaves, sbar=float(rep._sbar), episodes=episodes)
    with open(os.path.join(OUTR, "frozen_check.json"), "w") as f:
        json.dump(out, f)
    R = np.array([[r["etd"], r["mad"], r["half"], r["bias"]] for r in rows])
    print("frozen: pairs=%d  mad<=half: %.3f  median bias/etd=%.3f  median etd/half=%.3f" % (
        len(rows), np.mean(R[:, 1] <= R[:, 2] + 1e-9), np.median(R[:, 3] / R[:, 0]),
        np.median(R[:, 0] / R[:, 2])), flush=True)
    return out


# ---------------------------------------------------------------- danh muc thi nghiem
U = {k: P.JOBS[k] for k in ("u12", "u16", "u24")}
TD = dict(kind="adaptive", crit="td", tau=1.6)


def job(name):
    if name == "astar":
        res = {m: astar(m) for m in ("S", "M", "D")}
        for m, r in res.items():
            print("A* %s: steps=%s L=%s exp=%d %.1fs" % (m, r.get("steps"), r.get("length"),
                                                        r["expanded"], r["wall"]), flush=True)
        with open(os.path.join(OUTR, "astar.json"), "w") as f:
            json.dump(res, f)
        return
    if name == "frozen":
        frozen_check()
        return
    if name.startswith("dqn"):                                  # dqn_<map>_<seed>
        _, m, sd = name.split("_")
        run_dqn(name, seed=int(sd), mapname=m)
        return
    parts = name.split("_")                                     # <map>_<cfg>_s<seed>[_x<c>]
    m, cfg, sd = parts[0], parts[1], int(parts[2][1:])
    rs = float(parts[3][1:]) if len(parts) > 3 else 1.0
    if cfg == "td":
        spec = TD
    elif cfg == "count":
        spec = dict(kind="count")
    elif cfg.startswith("abs"):
        spec = dict(kind="abs", theta=float(cfg[3:]))
    else:
        spec = U[cfg]
    run_tab(name, spec, seed=sd, mapname=m, rscale=rs,
            save_q=(cfg == "td" and m == "M" and sd == 2026 and rs == 1.0))




# ============ 8. HINH 8-10 ============
import os, json, glob, math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
R = sys.modules[__name__]

RES = OUTR
FIGR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figs", "p2rf")
LANGR = "en"


def L2(en, vi):
    return vi if LANGR == "vi" else en


def J(name):
    with open(os.path.join(RES, name + ".json")) as f:
        return json.load(f)


def save2(fig, name):
    d = os.path.join(FIGR, LANGR)
    os.makedirs(d, exist_ok=True)
    fig.savefig(os.path.join(d, name), bbox_inches=None, pad_inches=0.0, dpi=600)
    plt.close(fig)
    print("  luu %s/%s" % (LANGR, name))


def num(x, nd=1):
    s = ("%." + str(nd) + "f") % x
    return s.replace(".", ",") if LANGR == "vi" else s


# ---------------------------------------------------------------- Hinh 8: hoi tu
def fig_conv(name="Fig8_convergence.png"):
    fig, axs = plt.subplots(1, 2, figsize=(14.8 * CM, 6.4 * CM))
    sty = ['-', '--', ':']
    for k, sd in enumerate((2026, 2027, 2028)):
        if not os.path.exists(os.path.join(RES, "M_td_s%d.json" % sd)):
            continue
        r = J("M_td_s%d" % sd)
        x = (np.arange(len(r["tdm"])) + 1) * 100
        axs[0].plot(x, r["tdm"], sty[k], color=OK[0], lw=1.2,
                    label=L2("Octree, seed %d" % sd, "Cây bát phân, hạt giống %d" % sd))
        g = np.array([[e, np.nan if v is None else v] for e, v in r["glen"]], float)
        axs[1].plot(g[:, 0], g[:, 1], sty[k], color=OK[0], lw=1.2, marker='o', ms=2.2)
    for k, sd in enumerate((2027, 2028)):
        f = os.path.join(RES, "M_u24_s%d.json" % sd)
        if not os.path.exists(f):
            continue
        r = J("M_u24_s%d" % sd)
        x = (np.arange(len(r["tdm"])) + 1) * 100
        axs[0].plot(x, r["tdm"], sty[k + 1], color=OK[1], lw=1.1,
                    label=L2("Uniform 24×24×10×8×3, seed %d" % sd,
                            "Lưới đều 24×24×10×8×3, hạt giống %d" % sd))
        g = np.array([[e, np.nan if v is None else v] for e, v in r["glen"]], float)
        axs[1].plot(g[:, 0], g[:, 1], sty[k + 1], color=OK[1], lw=1.1, marker='s', ms=2.0)
    axs[0].set_ylabel(L2("Mean $|\\zeta|$ per step", "Trung bình $|\\zeta|$ mỗi bước"))
    axs[1].set_ylabel(L2("Greedy path length (m)", "Chiều dài tuyến tham lam (m)"))
    axs[1].set_ylim(120, 330)
    axs[0].set_title(L2("(a) Temporal-difference error", "(a) Sai phân thời gian"))
    axs[1].set_title(L2("(b) Greedy track", "(b) Tuyến tham lam"))
    for ax in axs:
        ax.set_xlabel(L2("Training episode", "Tập huấn luyện"))
        ax.grid(True, alpha=0.3, ls=':')
        ax.set_xlim(0, 6100)
    h, lb = axs[0].get_legend_handles_labels()
    fig.legend(h, lb, loc='lower center', ncol=3, fontsize=7.0, framealpha=1.0,
               borderaxespad=0.2, handlelength=2.2, columnspacing=0.9, bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.4, rect=(0.0, 0.14, 1.0, 1.0))
    save2(fig, name)


# ---------------------------------------------------------------- Hinh 9: Menh de 1
def fig_stat(name="Fig9_statistic.png"):
    d = J("frozen_check")
    rows = d["rows"]; leaves = d["leaves"]
    fig, axs = plt.subplots(1, 2, figsize=(14.8 * CM, 6.6 * CM))
    cols = {3: OK[2], 4: OK[0], 5: OK[1]}
    mk = {3: 'o', 4: 's', 5: '^'}
    Pth = np.array(J("M_td_s2026")["path"])

    def dtrack(cell):
        D, i, j, k = cell
        n = 1 << D
        hx = P.CFG["Lx"] / n; hz = (P.CFG["Zmax"] - P.CFG["Zmin"]) / n
        c = np.array([(i + .5) * hx, (j + .5) * hx, P.CFG["Zmin"] + (k + .5) * hz])
        return float(np.min(np.linalg.norm(Pth - c, axis=1)))
    for D in (3, 4, 5):
        rr = [r for r in rows if r["depth"] == D]
        if not rr:
            continue
        axs[0].scatter([r["half"] for r in rr], [r["etd"] for r in rr], s=6, marker=mk[D],
                       color=cols[D], alpha=0.7, lw=0,
                       label=L2("Depth %d" % D, "Độ sâu %d" % D))
        ll = [l for l in leaves if l["cell"][0] == D]
        axs[1].scatter([dtrack(l["cell"]) for l in ll], [max(l["ebar"], 0.012) for l in ll], s=6,
                       marker=mk[D], color=cols[D], alpha=0.7, lw=0)
    axs[0].plot([0.1, 300], [0.1, 300], '-', color='0.3', lw=0.9,
                label=L2("Bound (19), $\\varepsilon_\\varphi = 0$", "Cận (19), $\\varepsilon_\\varphi = 0$"))
    axs[0].set_xlim(0.1, 300); axs[0].set_ylim(0.1, 300)
    axs[1].set_ylim(0.01, 100); axs[1].set_xlim(0, 90)
    axs[0].set_xscale('log')
    for ax in axs:
        ax.set_yscale('log')
        ax.grid(True, alpha=0.3, ls=':', which='both')
    axs[0].set_xlabel(L2("Half range of targets", "Nửa biên độ mục tiêu"))
    axs[0].set_ylabel(L2("Mean $|y-Q|$, frozen table", "Trung bình $|y-Q|$, bảng đóng băng"))
    axs[1].set_xlabel(L2("Distance to greedy track (m)", "Khoảng cách tới tuyến tham lam (m)"))
    axs[1].set_ylabel(L2("Leaf statistic $\\bar{e}_\\ell$", "Đại lượng của lá $\\bar{e}_\\ell$"))
    axs[0].set_title(L2("(a) Proposition 1", "(a) Mệnh đề 1"))
    axs[1].set_title(L2("(b) Statistic and flown corridor", "(b) Đại lượng và hành lang bay"))
    h, lb = axs[0].get_legend_handles_labels()
    fig.legend(h, lb, loc='lower center', ncol=4, fontsize=7.2, framealpha=1.0,
               borderaxespad=0.2, markerscale=2.0, bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.4, rect=(0.0, 0.10, 1.0, 1.0))
    save2(fig, name)


# ---------------------------------------------------------------- Hinh 10: ba ban do
def fig_maps(name="Fig10_maps.png"):
    A = J("astar")
    fig, axs = plt.subplots(1, 3, figsize=(14.8 * CM, 6.1 * CM))
    th = np.linspace(0, 2 * np.pi, 80)
    for ax, m in zip(axs, ("S", "M", "D")):
        for cx, cy, cz, Rr, kind in R.MAPS[m]:
            if kind == 1:
                c, a = ('#7B241C', 0.55) if 2 * cz >= 40 else ('#D55E00', 0.40)
            else:
                c, a = ('#E69F00', 0.30)
            ax.fill(cx + Rr * np.cos(th), cy + Rr * np.sin(th), color=c, alpha=a, lw=0.6, ec=c)
        for job, ls, col, lab in (("%s_td_s2026" % m, '-', OK[0],
                                   L2("Proposed octree", "Cây bát phân đề xuất")),
                                  ("%s_u24_s2026" % m, '--', OK[1],
                                   L2("Uniform 24×24×10×8×3", "Lưới đều 24×24×10×8×3"))):
            f = os.path.join(RES, job + ".json")
            if m == "M" and job.endswith("u24_s2026"):
                continue
            if os.path.exists(f):
                p = np.array(J(job)["path"])
                ax.plot(p[:, 0], p[:, 1], ls, color=col, lw=1.2, label=lab)
        if A.get(m, {}).get("path"):
            p = np.array(A[m]["path"])
            ax.plot(p[:, 0], p[:, 1], ':', color='k', lw=1.1, label=L2("A* search", "Tìm kiếm A*"))
        ax.plot(*P.CFG["start"][:2], 's', color='#009E73', ms=4.5, mec='k', mew=0.5)
        ax.plot(*P.CFG["goal"][:2], '*', color='#CC0000', ms=8, mec='k', mew=0.4)
        ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.set_aspect('equal')
        ax.set_title(L2("Map %s, %d threats", "Bản đồ %s, %d vùng") % (m, len(R.MAPS[m])))
        ax.set_xlabel('x (m)')
        ax.tick_params(labelsize=7.5)
    axs[0].set_ylabel('y (m)')
    from matplotlib.patches import Patch
    H, LB = [], []
    for ax in axs:
        for h_, l_ in zip(*ax.get_legend_handles_labels()):
            if l_ not in LB:
                H.append(h_); LB.append(l_)
    for c, a, l_ in (('#D55E00', 0.40, L2("Cylinder", "Trụ")),
                     ('#7B241C', 0.55, L2("Cylinder 40 m high", "Trụ cao 40 m")),
                     ('#E69F00', 0.30, L2("Sphere", "Cầu"))):
        H.append(Patch(fc=c, alpha=a, ec=c)); LB.append(l_)
    fig.legend(H, LB, loc='lower center', ncol=6, fontsize=6.8, framealpha=1.0,
               borderaxespad=0.2, handlelength=1.8, columnspacing=0.8, bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.35, rect=(0.0, 0.10, 1.0, 1.0))
    save2(fig, name)


def render_rev(lang):
    global LANGR
    LANGR = lang
    for f in (fig_conv, fig_stat, fig_maps):
        try:
            f()
        except Exception as e:                     # thieu du lieu
            print("  bo qua %s: %r" % (f.__name__, e))
    LANGR = "en"




# ============ 6. CHUONG TRINH CHINH ============
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--figs", action="store_true")
    ap.add_argument("--jobs", nargs="*", default=[])
    ap.add_argument("--ep", type=int, default=EP)
    ap.add_argument("--rev", nargs="*", default=[],
                    help="thi nghiem vong phan bien: <ban do>_<cau hinh>_s<hat giong>[_x<c>], "
                         "astar, frozen, dqn_<ban do>_<hat giong>")
    ap.add_argument("--revall", action="store_true", help="chay toan bo thi nghiem phan bien")
    ap.add_argument("--revfigs", action="store_true", help="ve Hinh 8, 9, 10")
    a = ap.parse_args()
    if a.rev or a.revall:
        lst = a.rev or REV_ALL
        for nm in lst:
            job(nm)
        if a.revall:
            a.revfigs = True
    if a.revfigs:
        for lg in ("en", "vi"):
            render_rev(lg)
    if a.rev or a.revall or a.revfigs:
        return
    jobs = list(a.jobs)
    ep = a.ep
    if a.all:
        jobs = list(JOBS)
    if a.quick:
        jobs, ep = ["u12", "a_td"], 1500
    for j in jobs:
        run(j, JOBS[j], episodes=ep)
    need = ("u08", "u12", "u16", "u20", "u24", "u32", "a_td", "a_value", "a_mix", "a_risk",
            "t_tau08", "t_tau24", "t_tau32")
    have = set(os.path.basename(f)[:-5] for f in glob.glob(os.path.join(OUT, "*.json")))
    if a.figs or a.all or all(n in have for n in need):
        for lg in ("en", "vi"):
            render_all(lg)
    else:
        print("Chua du ket qua de ve toan bo hinh; thieu:", [n for n in need if n not in have])


REV_ALL = ["M_td_s2026", "astar", "frozen",
           "M_td_s2027", "M_td_s2028", "M_u12_s2027", "M_u12_s2028", "M_u24_s2027", "M_u24_s2028",
           "S_td_s2026", "S_u12_s2026", "S_u24_s2026", "D_td_s2026", "D_u12_s2026", "D_u24_s2026",
           "M_count_s2026", "M_abs8_s2026", "M_td_s2026_x4", "M_abs8_s2026_x4", "dqn_M_2026"]


if __name__ == "__main__":
    main()
